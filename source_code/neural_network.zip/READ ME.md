If you don't have openpyxl installed in your operating system then you need to install it first as it will be required for reading data for excel reading reading in pandas
Create a virtual environment
Install the required libraries from requirements.txt file using pip install -r requirements.txt
Run the Engine.py file
You can change the epochs and the learning rate as per your convenience
If you want to make any changes to the code then you can use the ML_Pipeline folder. Preprocessing.py file preprocessing data and Neural_network.py is the file for neural network building.
